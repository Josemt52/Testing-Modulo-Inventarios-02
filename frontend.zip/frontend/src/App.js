import React, { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Navigate,
  useNavigate,
} from "react-router-dom";
import "./App.css";

import Productos from "./pages/Productos";
import Categorias from "./pages/Categorias";
import Marcas from "./pages/Marcas";
import Almacenes from "./pages/Almacenes";
import Movimientos from "./pages/Movimientos";

// Componente Login
function Login({ onLogin }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("http://localhost:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email,
          password: form.password,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.detail || "Error en la autenticación");
      }

      const userData = await res.json();      

      onLogin(userData);
      navigate("/productos");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{ maxWidth: 360, margin: "auto", padding: 20, fontFamily: "Arial, sans-serif" }}
    >
      <h2 style={{ textAlign: "center" }}>Iniciar Sesión</h2>

      <form
        onSubmit={handleSubmit}
        style={{ display: "flex", flexDirection: "column", gap: 12 }}
      >
        <input
          type="email"
          name="email"
          placeholder="Correo electrónico"
          value={form.email}
          onChange={handleChange}
          required
          style={{ padding: 8, fontSize: 16 }}
        />

        <input
          type="password"
          name="password"
          placeholder="Contraseña"
          value={form.password}
          onChange={handleChange}
          required
          style={{ padding: 8, fontSize: 16 }}
        />

        <button
          type="submit"
          disabled={loading}
          style={{ padding: 10, fontSize: 16 }}
        >
          {loading ? "Ingresando..." : "Ingresar"}
        </button>

        {error && <p style={{ color: "red", marginTop: 4 }}>{error}</p>}
      </form>

      <p style={{ marginTop: 20, textAlign: "center" }}>
        ¿No estás registrado?{" "}
        <Link to="/register" style={{ color: "blue", textDecoration: "underline" }}>
          Regístrate aquí
        </Link>
      </p>
    </div>
  );
}

// Componente Register
function Register() {
  const [form, setForm] = useState({
    nombre: "",
    rol: "",
    email: "",
    password: "",
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("http://localhost:8000/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.detail || "Error en el registro");
      }

      alert("Registro exitoso. Ahora puedes iniciar sesión.");
      navigate("/login");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{ maxWidth: 360, margin: "auto", padding: 20, fontFamily: "Arial, sans-serif" }}
    >
      <h2 style={{ textAlign: "center" }}>Registro de Usuario</h2>

      <form
        onSubmit={handleSubmit}
        style={{ display: "flex", flexDirection: "column", gap: 12 }}
      >
        <input
          type="text"
          name="nombre"
          placeholder="Nombre completo"
          value={form.nombre}
          onChange={handleChange}
          required
          style={{ padding: 8, fontSize: 16 }}
        />
        <input
          type="text"
          name="rol"
          placeholder="Rol (ej. administrador)"
          value={form.rol}
          onChange={handleChange}
          required
          style={{ padding: 8, fontSize: 16 }}
        />
        <input
          type="email"
          name="email"
          placeholder="Correo electrónico"
          value={form.email}
          onChange={handleChange}
          required
          style={{ padding: 8, fontSize: 16 }}
        />
        <input
          type="password"
          name="password"
          placeholder="Contraseña (min 8 caracteres)"
          value={form.password}
          onChange={handleChange}
          required
          minLength={8}
          style={{ padding: 8, fontSize: 16 }}
        />

        <button
          type="submit"
          disabled={loading}
          style={{ padding: 10, fontSize: 16 }}
        >
          {loading ? "Registrando..." : "Registrarse"}
        </button>

        {error && <p style={{ color: "red", marginTop: 4 }}>{error}</p>}
      </form>

      <p style={{ marginTop: 20, textAlign: "center" }}>
        ¿Ya tienes cuenta?{" "}
        <Link to="/login" style={{ color: "blue", textDecoration: "underline" }}>
          Volver a iniciar sesión
        </Link>
      </p>
    </div>
  );
}

// Ruta protegida para usuarios autenticados
function ProtectedRoute({ user, children }) {
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

export default function App() {
  const [mensaje, setMensaje] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch("http://localhost:8000/api/test")
      .then((res) => res.json())
      .then((data) => {
        setMensaje(data.message);
        console.log("Conexión exitosa con el backend:", data);
      })
      .catch((err) => {
        setMensaje("No se pudo conectar al backend");
        console.error("Error de conexión con el backend:", err);
      });
  }, []);

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <Router>
      <div className="App min-h-screen">
        <header className="App-header">
          <h1 className="text-3xl font-bold">Gestión de Inventario</h1>

          {user ? (
            <>
              <div className="mt-4">
                <Link to="/productos" className="App-link">
                  Productos
                </Link>
                <Link to="/categorias" className="App-link">
                  Categorías
                </Link>
                <Link to="/marcas" className="App-link">
                  Marcas
                </Link>
                <Link to="/almacenes" className="App-link">
                  Almacenes
                </Link>
                <Link to="/movimientos" className="App-link">
                  Movimientos
                </Link>
              </div>
              <button
                onClick={handleLogout}
                style={{
                  marginTop: 10,
                  background: "red",
                  color: "white",
                  padding: "6px 12px",
                  borderRadius: 4,
                }}
              >
                Cerrar sesión
              </button>
            </>
          ) : (
            <p className="mt-4 text-yellow-400">Por favor inicia sesión</p>
          )}
        </header>

        <main className="p-6">
          {mensaje && (
            <div className="mb-4 text-green-600 font-medium">{mensaje}</div>
          )}

          <Routes>
            <Route path="/login" element={<Login onLogin={setUser} />} />
            <Route path="/register" element={<Register />} />

            <Route
              path="/productos"
              element={
                <ProtectedRoute user={user}>
                  <Productos />
                </ProtectedRoute>
              }
            />
            <Route
              path="/categorias"
              element={
                <ProtectedRoute user={user}>
                  <Categorias />
                </ProtectedRoute>
              }
            />
            <Route
              path="/marcas"
              element={
                <ProtectedRoute user={user}>
                  <Marcas />
                </ProtectedRoute>
              }
            />
            <Route
              path="/almacenes"
              element={
                <ProtectedRoute user={user}>
                  <Almacenes />
                </ProtectedRoute>
              }
            />
            <Route
              path="/movimientos"
              element={
                <ProtectedRoute user={user}>
                  <Movimientos />
                </ProtectedRoute>
              }
            />

            {/* Redirige a login o productos según si está autenticado */}
            <Route
              path="*"
              element={<Navigate to={user ? "/productos" : "/login"} replace />}
            />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
