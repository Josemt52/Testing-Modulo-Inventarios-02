import React, { useEffect, useState } from "react";

export default function Categorias() {
  const [categorias, setCategorias] = useState([]);
  const [form, setForm] = useState({ nombre: "", id: null });

  const fetchCategorias = () => {
    fetch("http://localhost:8000/categorias")
      .then(res => res.json())
      .then(data => setCategorias(data))
      .catch(err => console.error("Error cargando categorías:", err));
  };

  useEffect(() => {
    fetchCategorias();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, nombre: e.target.value });
  };

  const guardarCategoria = () => {
    const method = form.id ? "PUT" : "POST";
    const url = form.id
      ? `http://localhost:8000/categorias/${form.id}`
      : "http://localhost:8000/categorias";

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre: form.nombre }),
    })
      .then(() => {
        setForm({ nombre: "", id: null });
        fetchCategorias();
      })
      .catch(err => console.error("Error al guardar categoría:", err));
  };

  const editarCategoria = (categoria) => {
    setForm(categoria);
  };

  const eliminarCategoria = (id) => {
  const confirmacion = window.confirm("¿Estás seguro que quieres eliminar esta categoría?");
  if (!confirmacion) return;

  fetch(`http://localhost:8000/categorias/${id}`, { method: "DELETE" })
    .then(() => fetchCategorias())
    .catch(err => console.error("Error eliminando categoría:", err));
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Gestión de Categorías</h2>

      <div className="flex items-center space-x-4 mb-4">
        <input
          className="border p-2 w-64"
          placeholder="Nombre de la categoría"
          value={form.nombre}
          onChange={handleChange}
        />
        <button onClick={guardarCategoria} className="bg-blue-500 text-white p-2 rounded">
          {form.id ? "Actualizar" : "Agregar"}
        </button>
      </div>

      <ul className="space-y-2">
        {categorias.map((c) => (
          <li key={c.id} className="flex justify-between bg-white p-2 border rounded">
            <span>{c.nombre}</span>
            <div className="space-x-2">
              <button onClick={() => editarCategoria(c)} className="text-blue-500">Editar</button>
              <button onClick={() => eliminarCategoria(c.id)} className="text-red-500">Eliminar</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
