import React, { useEffect, useState } from "react";

export default function Almacenes() {
  const [almacenes, setAlmacenes] = useState([]);
  const [form, setForm] = useState({ nombre: "", ubicacion: "", id: null });

  const fetchAlmacenes = () => {
    fetch("http://localhost:8000/almacenes")
      .then(res => res.json())
      .then(data => setAlmacenes(data))
      .catch(err => console.error("Error cargando almacenes:", err));
  };

  useEffect(() => {
    fetchAlmacenes();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const guardarAlmacen = () => {
    const method = form.id ? "PUT" : "POST";
    const url = form.id
      ? `http://localhost:8000/almacenes/${form.id}`
      : "http://localhost:8000/almacenes";

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre: form.nombre, ubicacion: form.ubicacion }),
    })
      .then(() => {
        setForm({ nombre: "", ubicacion: "", id: null });
        fetchAlmacenes();
      })
      .catch(err => console.error("Error al guardar almacén:", err));
  };

  const editarAlmacen = (almacen) => {
    setForm(almacen);
  };

  const eliminarAlmacen = (id) => {
  if (window.confirm("¿Estás seguro de que deseas desactivar este almacén?")) {
    fetch(`http://localhost:8000/almacenes/${id}`, { method: "DELETE" })
      .then(() => fetchAlmacenes())
      .catch(err => console.error("Error eliminando almacén:", err));
  }
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Gestión de Almacenes</h2>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <input
          name="nombre"
          value={form.nombre}
          onChange={handleChange}
          className="border p-2"
          placeholder="Nombre"
        />
        <input
          name="ubicacion"
          value={form.ubicacion}
          onChange={handleChange}
          className="border p-2"
          placeholder="Ubicación"
        />
      </div>

      <button onClick={guardarAlmacen} className="bg-blue-500 text-white p-2 rounded mb-4">
        {form.id ? "Actualizar" : "Agregar"}
      </button>

      <ul className="space-y-2">
        {almacenes.map((a) => (
          <li key={a.id} className="flex justify-between bg-white p-2 border rounded">
            <span>{a.nombre} - {a.ubicacion}</span>
            <div className="space-x-2">
              <button onClick={() => editarAlmacen(a)} className="text-blue-500">Editar</button>
              <button onClick={() => eliminarAlmacen(a.id)} className="text-red-500">Eliminar</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
