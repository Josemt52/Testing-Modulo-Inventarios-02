import React, { useState, useEffect } from "react";

const Producto = () => {
  const [productos, setProductos] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [marcas, setMarcas] = useState([]);
  const [form, setForm] = useState({
    nombre: "",
    categoria_id: "",
    marca_id: "",
    precio: "",
    stock_actual: "",
    stock_minimo: "",
  });
  const [error, setError] = useState(null);
  const [editarId, setEditarId] = useState(null); // Nuevo estado para editar

  useEffect(() => {
    fetch("http://localhost:8000/productos/todos")
      .then((res) => res.json())
      .then(setProductos)
      .catch(() => setError("Error al cargar productos"));

    fetch("http://localhost:8000/categorias/")
      .then((res) => res.json())
      .then(setCategorias)
      .catch(() => setError("Error al cargar categorías"));

    fetch("http://localhost:8000/marcas/")
      .then((res) => res.json())
      .then(setMarcas)
      .catch(() => setError("Error al cargar marcas"));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      !form.nombre ||
      !form.categoria_id ||
      !form.marca_id ||
      !form.precio ||
      !form.stock_actual ||
      !form.stock_minimo
    ) {
      setError("Todos los campos son obligatorios");
      return;
    }
    setError(null);
    const stockActual = parseInt(form.stock_actual);
    const stockMinimo = parseInt(form.stock_minimo);

    if (stockActual < stockMinimo) {
      alert("El stock actual no puede ser menor al stock mínimo.");
      return;
    }
    if (editarId) {
      // Actualizar producto
      const dataToSend2 = {
        ...form,
        categoria_id: parseInt(form.categoria_id),
        marca_id: parseInt(form.marca_id),
        precio: parseFloat(form.precio),
        stock_actual: parseInt(form.stock_actual),
        stock_minimo: parseInt(form.stock_minimo),
        activo: true,
      };
      console.log("Datos a enviar:", editarId);
      fetch(`http://localhost:8000/productos/${editarId}`, {
        method: "PUT", // o PATCH si prefieres
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          categoria_id: parseInt(form.categoria_id),
          marca_id: parseInt(form.marca_id),
          precio: parseFloat(form.precio),
          stock_actual: parseInt(form.stock_actual),
          stock_minimo: parseInt(form.stock_minimo),
          activo: true,
        }),
      })
        .then((res) => {
          if (!res.ok) {
            return res.json().then((err) => {
              throw new Error(err.detail || "Error al actualizar producto");
            });
          }
          return res.json();
        })
        .then((productoActualizado) => {
          setProductos((prev) =>
            prev.map((p) => (p.id === editarId ? productoActualizado : p))
          );
          setForm({
            nombre: "",
            categoria_id: "",
            marca_id: "",
            precio: "",
            stock_actual: "",
            stock_minimo: "",
          });
          setEditarId(null);
        })
        .catch((e) => setError(e.message));
    } else {
      // Crear nuevo producto
      fetch("http://localhost:8000/productos/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          categoria_id: parseInt(form.categoria_id),
          marca_id: parseInt(form.marca_id),
          precio: parseFloat(form.precio),
          stock_actual: parseInt(form.stock_actual),
          stock_minimo: parseInt(form.stock_minimo),
          activo: true,
        }),
      })
        .then((res) => {
          if (!res.ok) {
            return res.json().then((err) => {
              throw new Error(err.detail || "Error al crear producto");
            });
          }
          return res.json();
        })
        .then((nuevoProducto) => {
          setProductos((prev) => [...prev, nuevoProducto]);
          setForm({
            nombre: "",
            categoria_id: "",
            marca_id: "",
            precio: "",
            stock_actual: "",
            stock_minimo: "",
          });
        })
        .catch((e) => setError(e.message));
    }
  };

  const handleDelete = (id) => {
    const confirmacion = window.confirm(
      "¿Estás seguro de que quieres eliminar este producto? Esta acción no se puede deshacer."
    );
    if (!confirmacion) return;

    fetch(`http://localhost:8000/productos/${id}`, {
      method: "DELETE",
    })
      .then((res) => {
        if (res.status === 404) throw new Error("Producto no encontrado");
        if (!res.ok) throw new Error("Error al eliminar producto");
        setProductos((prev) => prev.filter((p) => p.id !== id));
      })
      .catch((e) => setError(e.message));
  };

  const handleEditar = (producto) => {
    setForm({
      nombre: producto.nombre,
      categoria_id: producto.categoria_id.toString(),
      marca_id: producto.marca_id.toString(),
      precio: producto.precio.toString(),
      stock_actual: producto.stock_actual.toString(),
      stock_minimo: producto.stock_minimo.toString(),
    });
    setEditarId(producto.id);
    setError(null);
  };

  const handleCancelarEdicion = () => {
    setForm({
      nombre: "",
      categoria_id: "",
      marca_id: "",
      precio: "",
      stock_actual: "",
      stock_minimo: "",
    });
    setEditarId(null);
    setError(null);
  };

  return (
    <div style={{ maxWidth: 900, margin: "auto", padding: 20 }}>
      <h2>Gestión de Productos</h2>

      {error && (
        <div style={{ color: "red", marginBottom: 10 }}>
          <strong>{error}</strong>
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input
          type="text"
          name="nombre"
          placeholder="Nombre"
          value={form.nombre}
          onChange={handleChange}
          style={{ marginRight: 10 }}
          required
        />

        <select
          name="categoria_id"
          value={form.categoria_id}
          onChange={handleChange}
          required
          style={{ marginRight: 10 }}
        >
          <option value="">-- Categoría --</option>
          {categorias.map((cat) => (
            <option key={cat.id} value={cat.id}>
              {cat.nombre}
            </option>
          ))}
        </select>

        <select
          name="marca_id"
          value={form.marca_id}
          onChange={handleChange}
          required
          style={{ marginRight: 10 }}
        >
          <option value="">-- Marca --</option>
          {marcas.map((marca) => (
            <option key={marca.id} value={marca.id}>
              {marca.nombre}
            </option>
          ))}
        </select>

        <input
          type="number"
          step="0.01"
          min="0"
          name="precio"
          placeholder="Precio"
          value={form.precio}
          onChange={handleChange}
          style={{ marginRight: 10, width: 80 }}
          required
        />

        <input
          type="number"
          min="0"
          name="stock_actual"
          placeholder="Stock Actual"
          value={form.stock_actual}
          onChange={handleChange}
          style={{ marginRight: 10, width: 100 }}
          required
        />

        <input
          type="number"
          min="0"
          name="stock_minimo"
          placeholder="Stock Mínimo"
          value={form.stock_minimo}
          onChange={handleChange}
          style={{ marginRight: 10, width: 100 }}
          required
        />

        <button type="submit">{editarId ? "Actualizar" : "Agregar"}</button>
        {editarId && (
          <button type="button" onClick={handleCancelarEdicion} style={{ marginLeft: 10 }}>
            Cancelar
          </button>
        )}
      </form>

      <table
        border="1"
        cellPadding="8"
        style={{ borderCollapse: "collapse", width: "100%" }}
      >
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Marca</th>
            <th>Precio</th>
            <th>Stock Actual</th>
            <th>Stock Mínimo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {productos.map((prod) => (
            <tr key={prod.id}>
              <td>{prod.nombre}</td>
              <td>{prod.categoria_nombre || prod.categoria_id}</td>
              <td>{prod.marca_nombre || prod.marca_id}</td>
              <td>{parseFloat(prod.precio).toFixed(2)}</td>
              <td>{prod.stock_actual}</td>
              <td>{prod.stock_minimo}</td>
              <td>
                <button onClick={() => handleEditar(prod)} style={{ marginRight: 8 }}>
                  Editar
                </button>
                <button onClick={() => handleDelete(prod.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
          {productos.length === 0 && (
            <tr>
              <td colSpan="7" style={{ textAlign: "center" }}>
                No hay productos
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Producto;
