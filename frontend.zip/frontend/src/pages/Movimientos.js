import React, { useEffect, useState } from "react";

export default function Movimientos() {
  const [movimientos, setMovimientos] = useState([]);
  const [productos, setProductos] = useState([]);
  const [almacenes, setAlmacenes] = useState([]);

  const [form, setForm] = useState({
    tipo: "entrada",
    cantidad: "",
    producto_id: "",
    almacen_id: "",
    origen: "",
    observaciones: ""
  });

  // Cargar movimientos
  const fetchMovimientos = () => {
    fetch("http://localhost:8000/inventario/movimientos")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setMovimientos(data);
        else setMovimientos([]);
      })
      .catch(err => console.error("Error cargando movimientos:", err));
  };

  // Cargar productos
  const fetchProductos = () => {
    fetch("http://localhost:8000/productos/todos")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setProductos(data);
        else setProductos([]);
      })
      .catch(err => {
        console.error("Error cargando productos:", err);
        setProductos([]);
      });
  };

  // Cargar almacenes
  const fetchAlmacenes = () => {
    fetch("http://localhost:8000/almacenes")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setAlmacenes(data);
        else setAlmacenes([]);
      })
      .catch(err => {
        console.error("Error cargando almacenes:", err);
        setAlmacenes([]);
      });
  };

  useEffect(() => {
    fetchMovimientos();
    fetchProductos();
    fetchAlmacenes();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const registrarMovimiento = () => {
    if (parseInt(form.cantidad) < 1 || isNaN(parseInt(form.cantidad))) {
      alert("La cantidad debe ser un número positivo mayor o igual a 1.");
      return;
    }

    const confirmar = window.confirm(
      "Advertencia: Los movimientos registrados no podrán ser editados ni eliminados.\n\n¿Deseas continuar?"
    );

    if (!confirmar) return;

    // Convertimos los valores necesarios a número (enteros)
    const dataToSend = {
      ...form,
      cantidad: parseInt(form.cantidad),
      producto_id: parseInt(form.producto_id),
      almacen_id: parseInt(form.almacen_id),
      origen: form.origen, // si también quieres enviar como ID: parseInt(form.origen)
    };

    console.log("📦 Enviando movimiento:", dataToSend); // 🔍 Mostrar en consola

    fetch("http://localhost:8000/movimientos/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dataToSend),
    })
      .then(res => {
        if (!res.ok) throw new Error("Error en la respuesta del servidor");
        return res.json();
      })
      .then(() => {
        setForm({
          tipo: "entrada",
          cantidad: "",
          producto_id: "",
          almacen_id: "",
          origen: "",
          observaciones: ""
        });
        fetchMovimientos();
      })
      .catch(err => console.error("Error registrando movimiento:", err));
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Movimientos de Inventario</h2>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <select
          name="tipo"
          value={form.tipo}
          onChange={handleChange}
          className="border p-2"
        >
          <option value="entrada">Entrada</option>
          <option value="salida">Salida</option>
        </select>

        <select
          name="producto_id"
          value={form.producto_id}
          onChange={handleChange}
          className="border p-2"
        >
          <option value="">Selecciona un producto</option>
          {Array.isArray(productos) && productos.map((p) => (
            <option key={p.id} value={p.id}>{p.nombre}</option>
          ))}
        </select>

        <input
          name="cantidad"
          value={form.cantidad}
          onChange={handleChange}
          placeholder="Cantidad"
          type="number"
          min="1"
          className="border p-2"
        />

        <select
          name="almacen_id"
          value={form.almacen_id}
          onChange={handleChange}
          className="border p-2"
        >
          <option value="">Selecciona un almacén</option>
          {Array.isArray(almacenes) && almacenes.map((a) => (
            <option key={a.id} value={a.id}>{a.nombre}</option>
          ))}
        </select>

        <select
          name="origen"
          value={form.origen}
          onChange={handleChange}
          className="border p-2"
        >
          <option value="">Selecciona un origen/destino</option>
          {Array.isArray(almacenes) && almacenes.map((a) => (
            <option key={a.id} value={a.nombre}>{a.nombre}</option>
          ))}
        </select>

        <input
          name="observaciones"
          value={form.observaciones}
          onChange={handleChange}
          placeholder="Observaciones"
          className="border p-2 col-span-2"
        />
      </div>

      <button
        onClick={registrarMovimiento}
        className="bg-blue-500 text-white p-2 rounded mb-4"
        disabled={!form.producto_id || !form.cantidad || !form.almacen_id}
      >
        Registrar Movimiento
      </button>

      <table className="w-full table-auto border">
        <thead>
          <tr className="bg-gray-200">
            <th>Tipo</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Almacén</th>
            <th>Origen/Destino</th>
            <th>Observaciones</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(movimientos) && movimientos.map((m) => (
            <tr key={m.id} className="text-center">
              <td>{m.tipo}</td>
              <td>{m.producto_id}</td>
              <td>{m.cantidad}</td>
              <td>{m.almacen_id}</td>
              <td>{m.origen}</td>
              <td>{m.observaciones}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
