import React, { useEffect, useState } from "react";

export default function Marcas() {
  const [marcas, setMarcas] = useState([]);
  const [form, setForm] = useState({ nombre: "", id: null });

  const fetchMarcas = () => {
    fetch("http://localhost:8000/marcas")
      .then(res => res.json())
      .then(data => setMarcas(data))
      .catch(err => console.error("Error cargando marcas:", err));
  };

  useEffect(() => {
    fetchMarcas();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, nombre: e.target.value });
  };

  const guardarMarca = () => {
    const method = form.id ? "PUT" : "POST";
    const url = form.id
      ? `http://localhost:8000/marcas/${form.id}`
      : "http://localhost:8000/marcas";

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre: form.nombre }),
    })
      .then(() => {
        setForm({ nombre: "", id: null });
        fetchMarcas();
      })
      .catch(err => console.error("Error al guardar marca:", err));
  };

  const editarMarca = (marca) => {
    setForm(marca);
  };

  const eliminarMarca = (id) => {
  const confirmar = window.confirm("¿Estás seguro de que deseas eliminar esta marca?");
  if (!confirmar) return;

  fetch(`http://localhost:8000/marcas/${id}`, { method: "DELETE" })
    .then(() => fetchMarcas())
    .catch(err => console.error("Error eliminando marca:", err));
  };


  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Gestión de Marcas</h2>

      <div className="flex items-center space-x-4 mb-4">
        <input
          className="border p-2 w-64"
          placeholder="Nombre de la marca"
          value={form.nombre}
          onChange={handleChange}
        />
        <button onClick={guardarMarca} className="bg-blue-500 text-white p-2 rounded">
          {form.id ? "Actualizar" : "Agregar"}
        </button>
      </div>

      <ul className="space-y-2">
        {marcas.map((m) => (
          <li key={m.id} className="flex justify-between bg-white p-2 border rounded">
            <span>{m.nombre}</span>
            <div className="space-x-2">
              <button onClick={() => editarMarca(m)} className="text-blue-500">Editar</button>
              <button onClick={() => eliminarMarca(m.id)} className="text-red-500">Eliminar</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
